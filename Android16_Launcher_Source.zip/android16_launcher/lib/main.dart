import 'package:flutter/material.dart';
import 'package:device_apps/device_apps.dart';

void main() => runApp(const Android16Launcher());

class Android16Launcher extends StatelessWidget {
  const Android16Launcher({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Android 16 Launcher',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
        primaryColor: Colors.blueAccent,
        colorScheme: const ColorScheme.dark(
          primary: Colors.blueAccent,
          secondary: Colors.blueAccent,
        ),
      ),
      home: const HomeScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background Wallpaper Gradient (Material You Style Accent)
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF1A237E), Colors.black],
              ),
            ),
          ),

          // Home Screen Content
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 60),
                // Dynamic Pixel-style Clock Widget
                const Text(
                  "10:00",
                  style: TextStyle(fontSize: 76, fontWeight: FontWeight.w200, color: Colors.white, letterSpacing: -2),
                ),
                const Text(
                  "Sunday, May 31",
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w400, color: Colors.white70),
                ),
                const Spacer(),

                // Bottom Search Bar (Android 16 Pill Style)
                Container(
                  margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(30),
                    border: Border.all(color: Colors.white12),
                  ),
                  child: Row(
                    children: const [
                      Icon(Icons.search, color: Colors.white70),
                      SizedBox(width: 12),
                      Text("Search apps and web...", style: TextStyle(color: Colors.white60, fontSize: 15)),
                      Spacer(),
                      Icon(Icons.mic, color: Colors.white70),
                    ],
                  ),
                ),

                // Gesture Trigger for App Drawer
                IconButton(
                  icon: const Icon(Icons.keyboard_arrow_up, color: Colors.white60, size: 32),
                  onPressed: () {
                    showModalBottomSheet(
                      context: context,
                      isScrollControlled: true,
                      backgroundColor: Colors.black.withOpacity(0.9),
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
                      ),
                      builder: (context) => const AppDrawer(),
                    );
                  },
                ),
                const Text("Swipe up for Apps", style: TextStyle(color: Colors.white38, fontSize: 12)),
                const SizedBox(height: 16),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      expand: false,
      initialChildSize: 0.85,
      maxChildSize: 0.95,
      minChildSize: 0.5,
      builder: (context, scrollController) {
        return FutureBuilder<List<Application>>(
          future: DeviceApps.getInstalledApplications(
            includeAppIcons: true,
            includeSystemApps: true,
            onlyAppsWithLaunchIntent: true,
          ),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator(color: Colors.blueAccent));
            }
            if (!snapshot.hasData || snapshot.data!.isEmpty) {
              return const Center(child: Text("No apps found", style: TextStyle(color: Colors.white)));
            }

            List<Application> apps = snapshot.data!;
            apps.sort((a, b) => a.appName.toLowerCase().compareTo(b.appName.toLowerCase()));

            return Column(
              children: [
                const SizedBox(height: 12),
                Container(
                  width: 45,
                  height: 5,
                  decoration: BoxDecoration(color: Colors.white30, borderRadius: BorderRadius.circular(10)),
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: Text(
                    "All Apps",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500, color: Colors.white80, letterSpacing: 0.5),
                  ),
                ),
                Expanded(
                  child: GridView.builder(
                    controller: scrollController,
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 4,
                      mainAxisSpacing: 24,
                      crossAxisSpacing: 12,
                      childAspectRatio: 0.82,
                    ),
                    itemCount: apps.length,
                    itemBuilder: (context, index) {
                      ApplicationWithIcon app = apps[index] as ApplicationWithIcon;
                      return GestureDetector(
                        onTap: () => DeviceApps.openApp(app.packageName),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            CircleAvatar(
                              backgroundColor: Colors.white.withOpacity(0.04),
                              radius: 28,
                              child: Image.memory(app.icon, width: 44, height: 44),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              app.appName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              textAlign: Center,
                              style: const TextStyle(color: Colors.white90, fontSize: 12),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
